import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import java.sql.*;
import java.nio.file.Path;
import java.nio.file.Paths;

public class MainApp extends Application {
    private static Connection conn;
    private static VBox todos = new VBox();

    public static void main(String[] args) {
        try {
                Path currentPath = Paths.get(System.getProperty("user.dir"));
                Path filePath = Paths.get(currentPath.toString(), "todos.sqlite3");

                String url = "jdbc:sqlite:" + filePath;
                conn = DriverManager.getConnection(url);

                //createTable();
                loadTasks();
                Application.launch(args);
        }
        catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
    }

    @Override
    public void start(Stage stage) {
        ScrollPane scrollPane = new ScrollPane(todos);

        TextField textField = new TextField();
        Button addButton = new Button("+");

        HBox controls = new HBox(8, textField, addButton);
        controls.setPadding(new Insets(8));

        BorderPane root = new BorderPane();
        root.setCenter(scrollPane);
        root.setBottom(controls);

        Scene scene = new Scene(root, 550, 500);
        stage.setScene(scene);
        stage.setTitle("HelloFX");
        stage.show();

        addButton.setOnAction((event) -> {
            addTask(textField.getText());
            textField.setText("");
        });
    }

    private static void renderTask(long id, String description) {
        Label text = new Label(description);
        Button removeButton = new Button("x");
        HBox todo = new HBox(8, text, removeButton);
        todo.setPadding(new Insets(8));
        todos.getChildren().add(todo);
        removeButton.setOnAction((event1) -> {
            todos.getChildren().remove(todo);
            removeTask(id);
        });
    }

    private static void createTable() {
        String sql = "CREATE TABLE IF NOT EXISTS tasks (\n"
                + "    id integer PRIMARY KEY,\n"
                + "    description text NOT NULL\n"
                + ");";

        try (Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    private static void addTask(String description) {
        String sql = "INSERT INTO tasks (description) VALUES (?)";

        try (PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, description);
            int affectedRows = stmt.executeUpdate();

            if (affectedRows == 0) {
                throw new SQLException("Не удалось добавить задачу");
            }

            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    renderTask(generatedKeys.getLong(1), description);
                } else {
                    throw new SQLException("Не удалось получить id");
                }
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    private static void loadTasks() {
        String sql = "SELECT * FROM tasks";

        try (PreparedStatement stmt  = conn.prepareStatement(sql)){
            ResultSet rs  = stmt.executeQuery();

            while (rs.next()) {
                renderTask(rs.getLong("id"), rs.getString("description"));
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    private static void removeTask(long id) {
        String sqlTransaction =
                "DELETE FROM tasks WHERE id = (?)";
        try{
            PreparedStatement preparedStatement =
                    conn.prepareStatement(sqlTransaction);
            preparedStatement.setLong(1, id);
            preparedStatement.executeUpdate();
        }
        catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }
}
